package com.kinesis.planets.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor

public class PlanetTypeSummaryDto {
	
	private Float planetSumValue;
	private Integer planetCount;
	
	public PlanetTypeSummaryDto(Float sumValue) {
		super();
		this.planetSumValue = sumValue;
		this.planetCount = 1;
	}
	
	public void addValue(Float value) {
		this.planetSumValue+=value;
		this.planetCount++;
	}	
}
