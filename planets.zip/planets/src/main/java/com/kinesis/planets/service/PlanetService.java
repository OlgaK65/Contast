package com.kinesis.planets.service;

import com.kinesis.planets.domain.PlanetTypeSummary;

public interface PlanetService {
	public PlanetTypeSummary getPlanetSummary(String eventType, long timestamp1, long timestamp2);
}
