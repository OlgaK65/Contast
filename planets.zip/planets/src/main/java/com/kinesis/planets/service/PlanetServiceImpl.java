package com.kinesis.planets.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazonaws.services.kinesis.clientlibrary.lib.worker.Worker;
import com.kinesis.planets.domain.PlanetType;
import com.kinesis.planets.domain.PlanetTypeSummary;
import com.kinesis.planets.dto.PlanetTypeSummaryDto;
import com.kinesis.planets.exceptions.SomethingBadException;

@Service
public class PlanetServiceImpl implements PlanetService {

	@Autowired
	Worker worker;
	
	@Autowired
	List<Long> timestamps;
	
	@Autowired
	Map<PlanetType, PlanetTypeSummaryDto> planetMap;
		
	@Override
	public PlanetTypeSummary getPlanetSummary(String eventType, long timestamp1, long timestamp2) {
		
		if(timestamp2 < timestamp1 || (timestamp2 - timestamp1) < 60000L)
			throw new SomethingBadException("Bad time interval!");
		
		if(PlanetType.valueOf(eventType) == null)
			throw new SomethingBadException("Bad planet type!");
		
		if(timestamps == null)
			throw new SomethingBadException("Bad array for time limits!");
		
		if(planetMap == null)
			throw new SomethingBadException("Bad working map!");
		
		planetMap.clear();
		timestamps.clear();
			
		timestamps.add(timestamp1);
		timestamps.add(timestamp2);
		
		try {
            worker.run();
        } catch (Throwable t) {
            System.err.println("Caught throwable while processing data.");
            t.printStackTrace();
        }
		
		PlanetTypeSummaryDto summary = planetMap.get(PlanetType.valueOf(eventType));
		return (summary == null) ? null : new PlanetTypeSummary(summary, eventType);
	}
}
