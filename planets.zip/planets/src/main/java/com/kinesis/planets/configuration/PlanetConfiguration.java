package com.kinesis.planets.configuration;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;

import com.amazonaws.services.kinesis.clientlibrary.interfaces.IRecordProcessorFactory;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.InitialPositionInStream;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.KinesisClientLibConfiguration;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.Worker;
import com.kinesis.planets.domain.PlanetType;
import com.kinesis.planets.dto.PlanetTypeSummaryDto;

@Configuration
public class PlanetConfiguration {
	 
	 public static final String SAMPLE_APPLICATION_STREAM_NAME = "myFirstStream";
	 private static final String SAMPLE_APPLICATION_NAME = "SampleKinesisApplication";
	 private static final InitialPositionInStream SAMPLE_APPLICATION_INITIAL_POSITION_IN_STREAM =
	            InitialPositionInStream.LATEST;
		
	 @Bean
	 public ProfileCredentialsProvider getProfileCredentialsProvider() {
		 ProfileCredentialsProvider credentialsProvider = new ProfileCredentialsProvider();
		 try {
			 credentialsProvider.getCredentials();
		 } catch (Exception e) {
			 throw new AmazonClientException("Cannot load the credentials from the credential profiles file. "
                  + "Please make sure that your credentials file is at the correct "
                  + "location (C:\\Users\\Olga\\.aws\\credentials), and is in valid format.", e);
		 }	 
		 return credentialsProvider;
	 }	 
	 
	 public KinesisClientLibConfiguration getKinesisClientLibConfiguration() throws Exception {
		 String workerId = InetAddress.getLocalHost().getCanonicalHostName() + ":" + UUID.randomUUID();
		 KinesisClientLibConfiguration kinesisClientLibConfiguration =
             new KinesisClientLibConfiguration(SAMPLE_APPLICATION_NAME,
                     SAMPLE_APPLICATION_STREAM_NAME,
                     getProfileCredentialsProvider(),
                     workerId);
     	return kinesisClientLibConfiguration.withInitialPositionInStream(SAMPLE_APPLICATION_INITIAL_POSITION_IN_STREAM);
	 }
	 
	 @Bean
	 public Worker getWorker() throws Exception { 
		 IRecordProcessorFactory recordProcessorFactory = new com.kinesis.planets.records.AmazonKinesisApplicationRecordProcessorFactory();
		 Worker worker = new Worker(recordProcessorFactory, getKinesisClientLibConfiguration());
		 return worker;
	 }	 
	 
	 @Bean
	 public Map<PlanetType, PlanetTypeSummaryDto> getPlanetMap(){
		 return new HashMap<PlanetType, PlanetTypeSummaryDto>();
	 }	 
	    
	 @Bean
	 public List<Long> getTimestamps() {
		return new ArrayList<Long>(); 
	 }	 
	 
	 @Bean
	 public String getSAMPLE_APPLICATION_STREAM_NAME() {
		 return SAMPLE_APPLICATION_STREAM_NAME; 
	 }
}
