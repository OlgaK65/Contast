package com.kinesis.producer;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.model.DescribeStreamRequest;
import com.amazonaws.services.kinesis.model.DescribeStreamResult;
import com.amazonaws.services.kinesis.model.StreamDescription;

import org.mockito.Mock;
import org.mockito.Mockito;

@SpringBootTest
class ProducerApplicationTests {

	@Mock
	AmazonKinesis kinesis;
	
	@Mock
	DescribeStreamRequest describeStreamRequest;
	
	@Mock
	DescribeStreamResult streamResult;
	
	@Mock
	StreamDescription streamDescription;
	
	@Test
	void testKinesisStreamName() {

        Mockito.when(kinesis.describeStream(describeStreamRequest)).thenReturn(streamResult);
        Mockito.when(streamResult.getStreamDescription()).thenReturn(streamDescription);    
        Mockito.when(streamDescription.getStreamName()).thenReturn("myFirstStream");
        
        String testString = kinesis.describeStream(describeStreamRequest)
        		                          .getStreamDescription()
                                          .getStreamName();
        assertEquals(testString, "myFirstStream");				
	}	
}
