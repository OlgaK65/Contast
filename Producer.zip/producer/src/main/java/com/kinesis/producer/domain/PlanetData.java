package com.kinesis.producer.domain;

import java.io.Serializable;

public class PlanetData implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long timestamp;
	private PlanetType planetType;
	private Float value;
	
	public PlanetData() {}
	
	public PlanetData(Long timestamp, PlanetType planetType, Float value) {
		super();
		this.timestamp = timestamp;
		this.planetType = planetType;
		this.value = value;
	}
	public Long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}
	public PlanetType getPlanetType() {
		return planetType;
	}
	public void setPlanetType(PlanetType planetType) {
		this.planetType = planetType;
	}
	public Float getValue() {
		return value;
	}
	public void setValue(Float value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "" + timestamp + ";" + planetType + ";" + value + ";" + "\n";
	}
}
