package com.kinesis.producer.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder;
import com.amazonaws.services.kinesis.model.CreateStreamRequest;
import com.amazonaws.services.kinesis.model.DescribeStreamRequest;
import com.amazonaws.services.kinesis.model.DescribeStreamResult;
import com.amazonaws.services.kinesis.model.ListStreamsRequest;
import com.amazonaws.services.kinesis.model.ListStreamsResult;
import com.amazonaws.services.kinesis.model.PutRecordRequest;
import com.amazonaws.services.kinesis.model.PutRecordResult;
import com.amazonaws.services.kinesis.model.ResourceNotFoundException;
import com.amazonaws.services.kinesis.model.StreamDescription;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kinesis.producer.domain.PlanetData;
import com.kinesis.producer.domain.PlanetType;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ProducerKinesisImpl implements ProducerKinesis {
	private static AmazonKinesis kinesis;
	   
    public static final String FILE_NAME = "objects";
    public static final String BUCKET_NAME = "sampledata-planets";
    private ProfileCredentialsProvider credentialsProvider;
    private static final Long Object_Number = 100L;
    private static final Float Max_Value = 100.f;
    private static final PlanetType[] planetValues = PlanetType.values(); 
    
    private void init() throws Exception {
        /*
         * The ProfileCredentialsProvider will return your [default]
         * credential profile by reading from the credentials file located at
         * (C:\\Users\\Olga\\.aws\\credentials).
         */
        credentialsProvider = new ProfileCredentialsProvider();
        try {
            credentialsProvider.getCredentials();
        } catch (Exception e) {
            throw new AmazonClientException(
                    "Cannot load the credentials from the credential profiles file. " +
                    "Please make sure that your credentials file is at the correct " +
                    "location (C:\\Users\\Olga\\.aws\\credentials), and is in valid format.",
                    e);
        }

        kinesis = AmazonKinesisClientBuilder.standard()
            .withCredentials(credentialsProvider)
            .withRegion("eu-central-1")
            .build();
    }
    
    private void waitForStreamToBecomeAvailable(String myStreamName) throws InterruptedException {
        System.out.printf("Waiting for %s to become ACTIVE...\n", myStreamName);

        long startTime = System.currentTimeMillis();
        long endTime = startTime + TimeUnit.MINUTES.toMillis(10);
        while (System.currentTimeMillis() < endTime) {
            Thread.sleep(TimeUnit.SECONDS.toMillis(20));

            try {
                DescribeStreamRequest describeStreamRequest = new DescribeStreamRequest();
                describeStreamRequest.setStreamName(myStreamName);
                // ask for no more than 10 shards at a time -- this is an optional parameter
                describeStreamRequest.setLimit(10);
                DescribeStreamResult describeStreamResponse = kinesis.describeStream(describeStreamRequest);

                String streamStatus = describeStreamResponse.getStreamDescription().getStreamStatus();
                System.out.printf("\t- current state: %s\n", streamStatus);
                if ("ACTIVE".equals(streamStatus)) {
                    return;
                }
            } catch (ResourceNotFoundException ex) {
                // ResourceNotFound means the stream doesn't exist yet,
                // so ignore this error and just keep polling.
            } catch (AmazonServiceException ase) {
                throw ase;
            }
        }

        throw new RuntimeException(String.format("Stream %s never became active", myStreamName));
    }
    
    private static  Set<String> loadFileFromS3(AmazonS3 amazonS3Client) {
        try (final S3Object s3Object = amazonS3Client.getObject(BUCKET_NAME,
                                                                FILE_NAME);
            final InputStreamReader streamReader = new InputStreamReader(s3Object.getObjectContent(), StandardCharsets.UTF_8);
            final BufferedReader reader = new BufferedReader(streamReader)) {
            return reader.lines().collect(Collectors.toSet());
        } catch (final IOException e) {
        	System.out.printf(e.getMessage());
            return Collections.emptySet();
        }
    }
    
    public void  startKinesis() throws Exception {
        init();

        final String myStreamName = "myFirstStream";
        final Integer myStreamSize = 1;
        init();
        
        final AmazonS3 amazonS3Client = AmazonS3ClientBuilder.standard()
				 .withCredentials(credentialsProvider)
                 .withRegion("us-east-1")
                 .build();

        // Describe the stream and check if it exists.
        DescribeStreamRequest describeStreamRequest = new DescribeStreamRequest().withStreamName(myStreamName);
        try {
            StreamDescription streamDescription = kinesis.describeStream(describeStreamRequest).getStreamDescription();
            System.out.printf("Stream %s has a status of %s.\n", myStreamName, streamDescription.getStreamStatus());

            if ("DELETING".equals(streamDescription.getStreamStatus())) {
                System.out.println("Stream is being deleted. This sample will now exit.");
                System.exit(0);
            }

            // Wait for the stream to become active if it is not yet ACTIVE.
            if (!"ACTIVE".equals(streamDescription.getStreamStatus())) {
                waitForStreamToBecomeAvailable(myStreamName);
            }
        } catch (ResourceNotFoundException ex) {
            System.out.printf("Stream %s does not exist. Creating it now.\n", myStreamName);

            // Create a stream. The number of shards determines the provisioned throughput.
            CreateStreamRequest createStreamRequest = new CreateStreamRequest();
            createStreamRequest.setStreamName(myStreamName);
            createStreamRequest.setShardCount(myStreamSize);
            kinesis.createStream(createStreamRequest);
            // The stream is now being created. Wait for it to become active.
            waitForStreamToBecomeAvailable(myStreamName);
        }

        // List all of my streams.
        ListStreamsRequest listStreamsRequest = new ListStreamsRequest();
        listStreamsRequest.setLimit(10);
        ListStreamsResult listStreamsResult = kinesis.listStreams(listStreamsRequest);
        List<String> streamNames = listStreamsResult.getStreamNames();
        while (listStreamsResult.isHasMoreStreams()) {
            if (streamNames.size() > 0) {
                listStreamsRequest.setExclusiveStartStreamName(streamNames.get(streamNames.size() - 1));
            }

            listStreamsResult = kinesis.listStreams(listStreamsRequest);
            streamNames.addAll(listStreamsResult.getStreamNames());
        }
        // Print all of my streams.
        System.out.println("List of my streams: ");
        for (int i = 0; i < streamNames.size(); i++) {
            System.out.println("\t- " + streamNames.get(i));
        }

        String jsonFormat = "{\"timestamp\":%d, \"planetType\":\"%s\", \"value\":%f}";
        ObjectMapper mapper = new ObjectMapper();
        Long count=1L;
        
        Set<String> lines = loadFileFromS3(amazonS3Client);
        for(String line: lines) {
        	
        	PlanetData data =  mapper.readValue(line, PlanetData.class);
        	PutRecordRequest putRecordRequest = new PutRecordRequest();
            putRecordRequest.setStreamName(myStreamName);
        	
        	String jsonVal = String.format(jsonFormat, data.getTimestamp(), data.getPlanetType(), data.getValue());
        	putRecordRequest.setData(ByteBuffer.wrap(jsonVal.getBytes()));
            putRecordRequest.setPartitionKey(String.format(Long.toString(count++)));
        	
            PutRecordResult putRecordResult = kinesis.putRecord(putRecordRequest);
            System.out.printf("Successfully put record, partition key : %s, ShardID : %s, SequenceNumber : %s.\n",
                    putRecordRequest.getPartitionKey(),
                    putRecordResult.getShardId(),
                    putRecordResult.getSequenceNumber());
            
        }
    }
     
	private void writeLocalFile() {
    	Random rni = new Random();
    	Random rnf = new Random();
    	
    	try(FileOutputStream fout = new FileOutputStream(FILE_NAME);) {
			
    		for(int i=0; i < Object_Number; i++) {
    			
    			int index = rni.nextInt() % 3;
    			if(index < 0)
    				index = 0;
    			PlanetType pType = planetValues[index];
    			
    			String planetString = new PlanetData(System.currentTimeMillis(),pType,rnf.nextFloat()*Max_Value)
    					                             .toString();	
    			log.info(planetString);
    			fout.write(planetString.getBytes());
    		}	
    		fout.flush();
    		fout.close();
		} catch (IOException e) {
			System.out.println("Error writing data");
		}
    }
    
    
    public void uploadFile() throws IOException {
    	
    	writeLocalFile();
    	
    	try {
    		AmazonS3Client s3Client = (AmazonS3Client)AmazonS3ClientBuilder.defaultClient();
    		File myFile =  new File(FILE_NAME);
    		PutObjectRequest myRequest = new PutObjectRequest(BUCKET_NAME, FILE_NAME, myFile)
    				                          .withCannedAcl(CannedAccessControlList.PublicRead);
    		
    		//s3Client.putObject(new PutObjectRequest(BUCKET_NAME, FILE_NAME, new File(FILE_NAME)).withCannedAcl(CannedAccessControlList.PublicRead));
    		s3Client.putObject(myRequest);
    		s3Client.getResourceUrl(BUCKET_NAME, FILE_NAME);
    	}catch (Exception e) {
			System.out.println("Error uploading file to a bucket");
		}
    	
    }
}
