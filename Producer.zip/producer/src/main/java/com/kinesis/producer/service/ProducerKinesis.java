package com.kinesis.producer.service;

import java.io.IOException;

public interface ProducerKinesis {
	public void  startKinesis() throws Exception;
	public void uploadFile() throws IOException; 
}
