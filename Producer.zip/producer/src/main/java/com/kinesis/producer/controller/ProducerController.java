package com.kinesis.producer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kinesis.producer.service.ProducerKinesis;

import io.swagger.v3.oas.annotations.Operation;

@RestController
public class ProducerController {
	
	@Autowired 
	ProducerKinesis service;
	
	@Operation(summary = "Reads from file and puts to kinesis stream", description = "Starts kinesis stream")
    //http://{hostname}/api/start
	@GetMapping("/api/start")
    public ResponseEntity<?> startStream() throws Exception {		
		service.startKinesis();
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@Operation(summary = "Uploads file to a bucket ", description = "Uploading file to a bucket")
	@GetMapping("/api/start/upload")
    public ResponseEntity<?> uploadFile() throws Exception {		
		service.uploadFile();
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
