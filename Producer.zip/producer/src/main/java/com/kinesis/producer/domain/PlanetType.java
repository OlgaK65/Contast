package com.kinesis.producer.domain;

public enum PlanetType {
	mars, earth, neptune
}
