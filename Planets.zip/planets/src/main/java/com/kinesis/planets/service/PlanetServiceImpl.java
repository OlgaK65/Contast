package com.kinesis.planets.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.model.AttributeAction;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.AttributeValueUpdate;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.CreateTableResult;
import com.amazonaws.services.dynamodbv2.model.GetItemRequest;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;

import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.Worker;
import com.amazonaws.services.kinesis.model.ResourceNotFoundException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kinesis.planets.domain.PlanetType;
import com.kinesis.planets.domain.PlanetTypeSummary;
import com.kinesis.planets.dto.PlanetTypeSummaryDto;
import com.kinesis.planets.exceptions.SomethingBadException;

@Service
public class PlanetServiceImpl implements PlanetService {

	@Autowired
	Worker worker;
	
	@Autowired
	List<Long> timestamps;
	
	//@Autowired
	//Map<PlanetType, PlanetTypeSummaryDto> planetMap;
	
	@Autowired 
	String SAMPLE_APPLICATION_NAME; 
	
	@Autowired
	String SAMPLE_APPLICATION_STREAM_NAME;
	
	@Autowired
	ProfileCredentialsProvider credentialsProvider;
	
	final AmazonDynamoDB ddb = AmazonDynamoDBClientBuilder.defaultClient();
	ObjectMapper mapper = new ObjectMapper();	
	final static String TABLE_NAME = "objects";
	
	@Override
	public PlanetTypeSummary getPlanetSummary(String eventType, long timestamp1, long timestamp2) throws JsonMappingException, JsonProcessingException {
		
		if(timestamp2 < timestamp1 || (timestamp2 - timestamp1) < 60000L)
			throw new SomethingBadException("Bad time interval!");
		
		if(PlanetType.valueOf(eventType) == null)
			throw new SomethingBadException("Bad planet type!");
		
		if(timestamps == null)
			throw new SomethingBadException("Bad array for time limits!");
		
		AmazonDynamoDB ddb = AmazonDynamoDBClientBuilder.defaultClient();
		createTable(ddb);

		timestamps.clear();			
		timestamps.add(timestamp1);
		timestamps.add(timestamp2);
		
		try {
            worker.run();
        } catch (Throwable t) {
            System.err.println("Caught throwable while processing data.");
            t.printStackTrace();
        }
		
		PlanetTypeSummaryDto summary = getObject(ddb, eventType);
		return (summary == null) ? null : new PlanetTypeSummary(summary, eventType);
	}
	
	public PlanetTypeSummaryDto getObject(AmazonDynamoDB ddb, String name) throws JsonMappingException, JsonProcessingException
	{
		HashMap<String,AttributeValue> key_to_get =
	            new HashMap<String,AttributeValue>();
		
	    key_to_get.put("DATABASE_NAME", new AttributeValue(name));

		GetItemRequest request = new GetItemRequest()
		                .withKey(key_to_get)
		                .withTableName(TABLE_NAME);
		
		try {
		    Map<String,AttributeValue> returned_item =
		               ddb.getItem(request).getItem();
		    if (returned_item != null) {
		        Set<String> keys = returned_item.keySet();
		        for (String key : keys) {
		            System.out.format("%s: %s\n",
		                            key, returned_item.get(key).toString());
		            return new PlanetTypeSummaryDto(returned_item.get(key));	            
		        }
		    } else {
		        System.out.format("No item found with the key %s!\n", name);
		    }
		  } catch (AmazonServiceException e) {
		        System.err.println(e.getErrorMessage());
		  }
		return null;		
	}
	
	public PlanetTypeSummaryDto putObject(AmazonDynamoDB ddb, String name, PlanetTypeSummaryDto sum) throws JsonProcessingException{
		
        HashMap<String,AttributeValue> item_values =
            new HashMap<String,AttributeValue>();

        item_values.put("Name", new AttributeValue(name)); 
        item_values.put(name, new AttributeValue(mapper.writeValueAsString(sum)));
       
        try {
            ddb.putItem(TABLE_NAME, item_values);
        } catch (ResourceNotFoundException e) {
            System.err.format("Error: The table \"%s\" can't be found.\n", TABLE_NAME);
            System.err.println("Be sure that it exists and that you've typed its name correctly!");
            System.exit(1);
        } catch (AmazonServiceException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
    	
		return sum;
	}

	public PlanetTypeSummaryDto updateObject(AmazonDynamoDB ddb, String name, PlanetTypeSummaryDto sum) throws JsonProcessingException{
		 
		ObjectMapper mapper = new ObjectMapper();
		HashMap<String,AttributeValue> item_key =
		           new HashMap<String,AttributeValue>();

		item_key.put("Name", new AttributeValue(name));

		HashMap<String,AttributeValueUpdate> updated_values =
		            new HashMap<String,AttributeValueUpdate>();        
		updated_values.put(name, new AttributeValueUpdate(
		                        new AttributeValue(mapper.writeValueAsString(sum)), AttributeAction.PUT));
		       
		try {
		    ddb.updateItem(TABLE_NAME, item_key, updated_values);
		} catch (ResourceNotFoundException e) {
		    System.err.println(e.getMessage());		            
		} catch (AmazonServiceException e) {
		    System.err.println(e.getMessage());
		}
		    	
		return sum;	
	}
		
	public ResponseEntity<?> deleteResource() {
		 AmazonKinesis kinesis = AmazonKinesisClientBuilder.standard()
		            .withCredentials(credentialsProvider)
		            .withRegion("eu-central-1")
		            .build();

		  try {
		      kinesis.deleteStream(SAMPLE_APPLICATION_STREAM_NAME);
		      
		  } catch (ResourceNotFoundException ex) {
		            // The stream doesn't exist.
		  }
		  
		// Delete the table
	      AmazonDynamoDB dynamoDB = AmazonDynamoDBClientBuilder.standard()
	          .withCredentials(credentialsProvider)
	          .withRegion("us-west-2")
	          .build();
	      System.out.printf("Deleting the Amazon DynamoDB table used by the Amazon Kinesis Client Library. Table Name = %s.\n",
	                SAMPLE_APPLICATION_NAME);
	      try {
	          dynamoDB.deleteTable(SAMPLE_APPLICATION_NAME);
	          return new ResponseEntity<>(HttpStatus.OK);
	      } catch (com.amazonaws.services.dynamodbv2.model.ResourceNotFoundException ex) {
	            // The table doesn't exist.
	      }
		  return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}	
	
	public static int createTable(AmazonDynamoDB ddb) {

		 CreateTableRequest request = new CreateTableRequest()
		            .withAttributeDefinitions(new AttributeDefinition(
		                     "Name", ScalarAttributeType.S))
		            .withKeySchema(new KeySchemaElement("Name", KeyType.HASH))
		            .withProvisionedThroughput(new ProvisionedThroughput(
		                     new Long(10), new Long(10)))
		            .withTableName(TABLE_NAME);
	 
		 try {
		     CreateTableResult result = ddb.createTable(request);
		            System.out.println(result.getTableDescription().getTableName());
		 } catch (AmazonServiceException e) {
		     System.err.println(e.getErrorMessage());
		     return 1;
		 }
		 return 0;
	 }
}
