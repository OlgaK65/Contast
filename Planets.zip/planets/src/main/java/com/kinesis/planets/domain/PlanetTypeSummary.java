package com.kinesis.planets.domain;

import com.kinesis.planets.dto.PlanetTypeSummaryDto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor

public class PlanetTypeSummary {
	
	private PlanetType planetType;
	private Float planetSumValue; 
	private Integer planetCount;
	
	public PlanetTypeSummary(PlanetTypeSummaryDto planetDto, String type) {
		super();
		this.planetType = PlanetType.valueOf(type);
		this.planetCount = planetDto.getPlanetCount();
		if(this.planetCount != 0) 
			this.planetSumValue = planetDto.getPlanetSumValue()/this.planetCount;
		else
			this.planetSumValue = (float) 0.;
	}	
}
