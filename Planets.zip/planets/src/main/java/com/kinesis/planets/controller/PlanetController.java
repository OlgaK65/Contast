package com.kinesis.planets.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.kinesis.planets.domain.PlanetTypeSummary;
import com.kinesis.planets.service.PlanetService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class PlanetController {
	
	
	@Autowired
	PlanetService service;
	
	@Autowired
	ProfileCredentialsProvider credentialsProvider;
	
	@Autowired
	String SAMPLE_APPLICATION_STREAM_NAME;
	 
	@Operation(summary = "Get average value and counts by type and timestamps ", description = "Returns data by params",
	            responses = {@ApiResponse(content = @Content(schema = @Schema(implementation = PlanetTypeSummary.class)))})
	//http://{hostname}/api/events/{eventType}/average
	@GetMapping("/api/events/{eventt}/average")
	public ResponseEntity<?> getPlanetSummary(@PathVariable("eventt") String eventType,
												@RequestParam(value = "from", required = true)  long from,
												@RequestParam(value = "to", required = true)  long to){  
	        try {
	             return new ResponseEntity<>(service.getPlanetSummary(eventType, from, to), HttpStatus.OK);
	        } catch (Exception ex) {
	            log.error("Error: {}", ex.getMessage());
	            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    }
	
	@Operation(summary = "Delete kinesis stream", description = "Delete kinesis stream")        
	//http://{hostname}/api/events/
	@DeleteMapping("/api/events")
	public ResponseEntity<?> deleteKinesisStream() {
		 return service.deleteResource();
    }
}
