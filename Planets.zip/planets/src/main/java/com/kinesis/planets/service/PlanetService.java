package com.kinesis.planets.service;

import org.springframework.http.ResponseEntity;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.kinesis.planets.domain.PlanetTypeSummary;
import com.kinesis.planets.dto.PlanetTypeSummaryDto;

public interface PlanetService {
	public PlanetTypeSummary getPlanetSummary(String eventType, long timestamp1, long timestamp2) throws JsonMappingException, JsonProcessingException;
	public ResponseEntity<?> deleteResource(); 
	public PlanetTypeSummaryDto getObject(AmazonDynamoDB ddb, String name) throws JsonMappingException, JsonProcessingException;
	public PlanetTypeSummaryDto putObject(AmazonDynamoDB ddb, String name, PlanetTypeSummaryDto sum) throws JsonProcessingException;
	public PlanetTypeSummaryDto updateObject(AmazonDynamoDB ddb, String name, PlanetTypeSummaryDto sum) throws JsonProcessingException;
}
