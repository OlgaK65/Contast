package com.kinesis.planets.dto;

import java.io.Serializable;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor

public class PlanetTypeSummaryDto implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Float planetSumValue;
	private Integer planetCount;
	
	public PlanetTypeSummaryDto(Float sumValue) {
		super();
		this.planetSumValue = sumValue;
		this.planetCount = 1;
	}
	
	public void addValue(Float value) {
		this.planetSumValue+=value;
		this.planetCount++;
	}

	public PlanetTypeSummaryDto(AttributeValue attributeValue) throws JsonMappingException, JsonProcessingException {
		super();
		
		ObjectMapper mapper = new ObjectMapper();
		String strAttribute = attributeValue.toString();
		PlanetTypeSummaryDto ptsDto = mapper.readValue(strAttribute, PlanetTypeSummaryDto.class);
		
		
		this.planetSumValue = ptsDto.planetSumValue; 
		this.planetCount = ptsDto.planetCount;
	}	
}
