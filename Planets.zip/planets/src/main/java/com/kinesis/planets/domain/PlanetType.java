package com.kinesis.planets.domain;

public enum PlanetType {
	mars, earth, neptune
}
