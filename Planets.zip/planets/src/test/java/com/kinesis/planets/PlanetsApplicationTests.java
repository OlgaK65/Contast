package com.kinesis.planets;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.model.GetRecordsRequest;
import com.amazonaws.services.kinesis.model.GetRecordsResult;
import com.amazonaws.services.kinesis.model.Record;


@SpringBootTest
class PlanetsApplicationTests {

	@Mock
	AmazonKinesis kinesis;
	
	@Mock
	GetRecordsResult recordsRezult;
	
	@Mock
	GetRecordsRequest recordsRequest;
	
	@Mock
	List<Record> list;
		
	@Test
	void testRecordList() {
		
		list = new ArrayList<Record>();
		for(int i = 0; i < 10; i++)
			list.add(new Record());
		
		Mockito.when(kinesis.getRecords(recordsRequest)).thenReturn(recordsRezult);
		Mockito.when(recordsRezult.getRecords()).thenReturn(list);
			
		assertEquals(kinesis.getRecords(recordsRequest).getRecords().size(),10);
	}	
}
